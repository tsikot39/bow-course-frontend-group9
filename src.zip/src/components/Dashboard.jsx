import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function Dashboard() {
  const [student, setStudent] = useState(null);
  const [selectedCourses, setSelectedCourses] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const storedStudent = localStorage.getItem("student");
    const storedCourses = localStorage.getItem("selectedCourses");

    if (storedStudent) {
      setStudent(JSON.parse(storedStudent));
    }
    if (storedCourses) {
      setSelectedCourses(JSON.parse(storedCourses));
    }
  }, []);

  const handleRegisterCourses = () => {
    navigate("/courses");
  };

  return (
    <div className="container">
      <h2>Dashboard</h2>
      {student ? (
        <div>
          <p>
            Welcome, {student.firstName} {student.lastName}
          </p>
          <p>Username: {student.username}</p>
          <p>Email: {student.email}</p>
          <p>Phone: {student.phone}</p>

          <h3>Selected Courses</h3>
          {selectedCourses.length > 0 ? (
            <ul className="selected-courses-list">
              {selectedCourses.map((course) => (
                <li key={course.id}>
                  {course.name} ({course.code}) - {course.term}
                </li>
              ))}
            </ul>
          ) : (
            <p>No courses selected.</p>
          )}

          <button onClick={handleRegisterCourses}>Register for Courses</button>
        </div>
      ) : (
        <p>No student data available</p>
      )}
    </div>
  );
}

export default Dashboard;
