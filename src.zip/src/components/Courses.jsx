import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function Courses() {
  const coursesData = [
    { id: 1, name: "Web Development", code: "WD101", term: "Fall" },
    { id: 2, name: "Data Structures", code: "DS102", term: "Fall" },
    { id: 3, name: "Algorithms", code: "ALG202", term: "Winter" },
    { id: 4, name: "Databases", code: "DB303", term: "Winter" },
  ];

  const [selectedCourses, setSelectedCourses] = useState([]);
  const navigate = useNavigate();

  const handleCourseSelect = (course) => {
    if (!selectedCourses.includes(course)) {
      setSelectedCourses([...selectedCourses, course]);
    }
  };

  const handleCourseRemove = (course) => {
    setSelectedCourses(selectedCourses.filter((c) => c.id !== course.id));
  };

  const handleSaveCourses = () => {
    localStorage.setItem("selectedCourses", JSON.stringify(selectedCourses));
    navigate("/dashboard");
  };

  return (
    <div className="container">
      <h2>Available Courses</h2>
      <ul className="courses-list">
        {coursesData.map((course) => (
          <li key={course.id}>
            {course.name} ({course.code}) - {course.term}
            <button onClick={() => handleCourseSelect(course)}>Add</button>
          </li>
        ))}
      </ul>

      <h3>Selected Courses</h3>
      <ul className="selected-courses-list">
        {selectedCourses.map((course) => (
          <li key={course.id}>
            {course.name} ({course.code}) - {course.term}
            <button onClick={() => handleCourseRemove(course)}>Remove</button>
          </li>
        ))}
      </ul>

      <button onClick={handleSaveCourses}>Save Courses</button>
    </div>
  );
}

export default Courses;
