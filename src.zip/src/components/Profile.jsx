import React, { useState, useEffect } from "react";

function Profile() {
  const [student, setStudent] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    username: "",
  });

  useEffect(() => {
    const storedStudent = localStorage.getItem("student");
    if (storedStudent) {
      setStudent(JSON.parse(storedStudent));
    }
  }, []);

  const handleChange = (e) => {
    setStudent({
      ...student,
      [e.target.name]: e.target.value,
    });
  };

  const handleSave = () => {
    localStorage.setItem("student", JSON.stringify(student));
    alert("Profile updated!");
  };

  return (
    <div>
      <h2>Your Profile</h2>
      <input
        name="firstName"
        value={student.firstName}
        onChange={handleChange}
      />
      <input name="lastName" value={student.lastName} onChange={handleChange} />
      <input name="email" value={student.email} onChange={handleChange} />
      <input name="phone" value={student.phone} onChange={handleChange} />
      <input name="username" value={student.username} onChange={handleChange} />
      <button onClick={handleSave}>Save</button>
    </div>
  );
}

export default Profile;
